#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    int array[9] = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    int new_array[9]={0},i=0,j=0;
    char input[9], input2[9];

    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            printf("%5d",array[i*3+j]);
        }
        printf("\n");
    }
    printf("Input password : ");
    scanf("%s", input);
//    for(j=0;j<strlen(input);j++)
//        printf("%d\n",input[j]);

    for(i=0;i<9;i++)
    {
        for(j=0;j<strlen(input);j++)
        {
            if(array[i] == (input[j]-48))
                new_array[i] = 1;
        }
    }

    for(i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            printf("%5d",new_array[i*3+j]);
        }
        printf("\n");
    }



    while(1)
    {
        printf("Input password : ");
    scanf("%s", input2);
        if(strcmp(input, input2) == 0)
        {
            printf("Login");
            return 0;
        }
        else
        {
            printf("Error\n");
//            return 0;
        }
    }



    return 0;
}

