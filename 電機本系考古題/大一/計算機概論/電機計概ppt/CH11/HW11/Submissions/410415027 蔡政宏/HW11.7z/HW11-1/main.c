#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{

    char str[10];
    printf("please input Register or Login or Quit:");
    scanf("%s",str);



    if(str=="quit")
    {
        return 0;
    }
    else if(strcmp(str, "register") == 0)
    {
        FILE*input1;
        FILE*input2;

        char Account[100],Password[100];
        char old_Account[100],old_Password[100];
        int a =0;

        input1=fopen("sql.txt","a");
        input2=fopen("sql.txt","r");

        printf("Please input Account and Password\n");
        printf("New Account:");
        scanf("%s",Account);
        printf("New Password:");
        scanf("%s",Password);

        while(fscanf(input2, "%s %s", old_Account, old_Password) != EOF)
        {
            if(strcmp(old_Account, Account) == 0)
                a = 1;
        }

        if(a==1)
        {
            printf("Repeat");
            return 0;
        }
        else
        {
            printf("It's OK to USE");

            fprintf(input1, "%s %s\n", Account, Password);

        }
        fclose(input1);
        fclose(input2);
    }
    else if(strcmp(str, "login")==0)
    {
        FILE*input1;
        FILE*input2;

        char Account[100],Password[100];
        char old_Account[100],old_Password[100];
        int b =0;

        input1=fopen("sql.txt","a");
        input2=fopen("sql.txt","r");

        printf("Please input Account and Password\n");
        printf("Account:");
        scanf("%s",Account);
        printf("Password:");
        scanf("%s",Password);

        while(fscanf(input2, "%s %s", old_Account, old_Password) != EOF)
        {
            if(strcmp(old_Password, Password) == 0 && strcmp(old_Account, Account) == 0)
                b = 1;
        }

        if(b==1)
        {
            printf("Login Success");
        }
        else
        {
            printf("password fail");
        }
        fclose(input1);
        fclose(input2);

        return 0;
    }
}
