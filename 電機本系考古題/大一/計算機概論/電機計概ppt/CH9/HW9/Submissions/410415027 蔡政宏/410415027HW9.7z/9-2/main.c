#include <stdio.h>
#include <stdlib.h>


int ans=0;

int fraction(int n)
{
    int ans=0;
    if(n==0)
        ans = 0;
    else if(n<=2)
        ans = 1;
    else
        ans=fraction(n-1)+fraction(n-2);

    return ans;

}


int main()
{
    int n=0,a[31]= {0}, i=0;
    int sum=0;
    printf("number=");
    scanf("%d",&n);

    while(i<n+1)
    {
        printf("f(%d) = %d\n",i, fraction(i));
        sum += fraction(i);
        i++;
    }

    printf("sum=%d",sum);

    return 0;
}
