#include <stdio.h>
#include <stdlib.h>

int count=0;

int fraction(int n,char A,char B,char C)
{


    if(n==1)
    {
        printf("n=%d, number=%d, from %c to %c\n",count++,n,A,C);
    }
    else
    {
        fraction(n-1,A,C,B);
        printf("n=%d, number=%d, from %c to %c\n",count++,n,A,C);
        fraction(n-1,B,A,C);
    }
}

int main()
{
    int n=0;
    printf("layer num:");
    scanf("%d",&n);


    fraction(n,'A','B','C');

    printf("%d",count);

    return 0;
}

