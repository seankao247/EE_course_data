#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i=0,j=0,isused;
    int len=25;
    srand(time(NULL));
    int array[25]= {0};
    int sort[5][5]= {0};

    for(i=0; i<25; i++)
    {
        do
        {
            array[i]=(rand()%51)+150;
            isused=0;
            for(j=0; j<i; j++)
            {
                if(array[j]==array[i])
                {
                    isused=1;
                    break;
                }
            }
        }
        while(isused==1);
    }

    printf("random number:");
    for(i=0; i<25; i++)
    {
        printf("%5d\n",array[i]);
    }

    for(i=0; i<len; i++)
    {
        j=i;
        while((j>=0) && array[j-1]>=array[j])
        {
            int temp=array[j];
            array[j]=array[j-1];
            array[j-1]=temp;
            j--;
        }
    }

    printf("sorting number:\n");
    for(i=0; i<25; i++)
    {
        printf("%5d\n",array[i]);
    }


    printf("\nGraduation photo:\n");
    for(i=4; i>=0; i--)
    {
        for(j=4; j>=0; j--)
        {
            sort[i][j]=array[5*i+j];
            printf("%5d",sort[i][j]);
        }
        printf("\n");
    }




    return 0;
}
