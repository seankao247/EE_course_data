#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i=0,j=0,k=0,l=0,step=0,isused;
    int len=25;
    srand(time(NULL));
    int array[25]={0};
    int sort[5][5]={0};

    for(i=0;i<25;i++)
    {
        do
        {
            array[i]=(rand()%25)+1;
            isused=0;
            for(j=0;j<i;j++)
            {
                if(array[j]==array[i])
                {
                    isused=1;
                    break;
                }
            }
        }while(isused==1);
    }




    for(i=0;i<5;i++)
    {
        for(j=0;j<5;j++)
        {
            sort[i][j]=array[5*i+j];
            printf("%5d  ",sort[i][j]);
        }
        printf("\n");
    }

    i=0;
    j=0;
    while(i<5||j<5)
    {

        if(i==4&&j==4)
        {
            break;
        }
        else if(i==4)
        {
            printf("right %d\n",sort[i][j+1]);
            step=step+sort[i][j+1];
            j++;
        }
        else if(j==4)
        {
            printf("down %d\n",sort[i+1][j]);
            step=step+sort[i+1][j];
            i++;
        }
        else if(sort[i+1][j]>=sort[i][j+1])
        {
            printf("down %d\n",sort[i][j+1]);
            step=step+sort[i][j+1];
            j++;
        }
        else if(sort[i+1][j]<=sort[i][j+1])
        {
            printf("right %d\n",sort[i+1][j]);
            step=step+sort[i+1][j];
            i++;
        }

    }

    printf("step=%d",step);

    return 0;
}
