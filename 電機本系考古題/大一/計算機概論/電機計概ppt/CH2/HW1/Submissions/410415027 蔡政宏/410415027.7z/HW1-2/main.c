#include <stdio.h>
#include <stdlib.h>

int main()
{
    int radius;
    float pi = 3.1415;
    float area, v;
    scanf("%d",&radius);

    area = radius * radius * pi;
    v = (pi * radius * radius * radius) * 4 / 3;
    printf("area = %f\n v = %f\n",area,v);

    system("pause");
    return 0;
}
