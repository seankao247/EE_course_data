#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    float b;
    scanf("%d",&a);

    if(a>0 && a<=100000)
        printf ("ans : %f", a*0.1);
    else if(100000<a && a<=200000)
    {
        b = (a-100000)*0.075+100000*0.1;
        printf ("ans : %f", b);
    }
    else if(200000<a && a<=400000)
    {
        b = (a-200000)*0.05+100000*0.075+100000*0.1;
        printf ("ans : %f", b);
    }
    else if(400000<a && a<=600000)
    {
        b  = (a-400000)*0.03+200000*0.05+100000*0.075+100000*0.1;
        printf ("ans : %f", b);
    }
    else if(600000<a && a<=1000000)
    {
        b = (a-600000)*0.015+200000*0.03+200000*0.05+100000*0.075+100000*0.1;
        printf ("ans : %f", b);
    }
    else if(a>1000000)
    {
        b = (a-1000000)*0.01+400000*0.015+200000*0.03+200000*0.05+100000*0.075+100000*0.1;
        printf ("ans : %f", b);
    }
    else
        printf("error");

    system("pause");
    return 0;
}
