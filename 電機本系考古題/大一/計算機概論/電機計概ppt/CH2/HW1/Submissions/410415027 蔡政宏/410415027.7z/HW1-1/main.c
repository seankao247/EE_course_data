#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int y,c,m,d,w;

    scanf("%d",&c);
    scanf("%d",&y);
    scanf("%d",&m);
    scanf("%d",&d);

    w=(y+(y/4)+(c/4)-2*c+(26*(m+1)/10)+d-1)%7;

    printf("ans : %d", w);


    system("pause");
    return 0;
}
