#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int A,B,Operation,ans;
    scanf("%d",&A);
    scanf("%d",&B);
    scanf("%d",&Operation);

    if(Operation == 1)
    {
		ans = pow(A,B);
		printf("ans : %d", ans);
    }
    else if(Operation == 2)
    {
        ans = pow(A,0.5);
		printf("ans : %d", ans);
    }
    else if(Operation == 3)
    {
        if(A%2==1)
        {
			printf("A�O���");
		}
        else
        {
			printf("A�O����");
        }
    }
    else if(Operation == 4)
    {
        if(B%2==1)
        {
            printf("B�O���");
        }
        else
        {
            printf("B�O����");
        }
    }
    else
    {
        printf("�L�Ī�Opreation");
    }
    system("pause");
    return 0;
}
