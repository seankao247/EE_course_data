#include <stdio.h>
#include <stdlib.h>

int main()
{
    int y,m,d,x;

    printf("date(yyyy mm dd):");
    scanf("%d,%d,%d",&y,&m,&d);




    if((y%4==0 && y%100!=0)||y%400==0)
    {
        switch(m)
        {
            case 1:
                x = 366-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 2:
                x = 335-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 3:
                x = 306-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 4:
                x = 275-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 5:
                x = 245-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 6:
                x = 214-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 7:
                x = 184-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 8:
                x = 153-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 9:
                x = 122-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 10:
                x = 92-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 11:
                x = 61-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 12:
                x = 31-d;
                printf(" %d days to go before the New Year.",x);
                break;
        }
    }
    else
    {
         switch(m)
        {
            case 1:
                x = 365-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 2:
                x = 334-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 3:
                x = 306-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 4:
                x = 275-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 5:
                x = 245-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 6:
                x = 214-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 7:
                x = 184-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 8:
                x = 153-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 9:
                x = 122-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 10:
                x = 92-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 11:
                x = 61-d;
                printf(" %d days to go before the New Year.",x);
                break;
            case 12:
                x = 31-d;
                printf(" %d days to go before the New Year.",x);
                break;
        }
    }
    return 0;
}
