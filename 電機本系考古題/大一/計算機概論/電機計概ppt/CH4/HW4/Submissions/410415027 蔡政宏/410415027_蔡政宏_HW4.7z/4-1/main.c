#include <stdio.h>
#include <stdlib.h>

int main()
{
    int random1,random2;

    srand(time(NULL));

    random1 = (rand()%4)+1;
    random2 = (rand()%13)+1;

    printf("your random color is: %d\n", random1);
    printf("your random number is: %d\n", random2);

    switch (random1)
    {
        case 1:
            printf("your input is:club-");
            break;
        case 2:
            printf("your input is:diamond-");
            break;
        case 3:
            printf("your input is:heart-");
            break;
        case 4:
            printf("your input is:spade-");
            break;
    }

    switch (random2)
    {
        case 1:
            printf("A");
            break;
        case 2:
            printf("2");
            break;
        case 3:
            printf("3");
            break;
        case 4:
            printf("4");
            break;
        case 5:
            printf("5");
            break;
        case 6:
            printf("6");
            break;
        case 7:
            printf("7");
            break;
        case 8:
            printf("8");
            break;
        case 9:
            printf("9");
            break;
        case 10:
            printf("10");
            break;
        case 11:
            printf("J");
            break;
        case 12:
            printf("Q");
            break;
        case 13:
            printf("K");
            break;
    }

    return 0;
}
