#include <stdio.h>
#include <stdlib.h>

int main()
{
    int input1,input2,input3,random1;

    srand(time(NULL));

    random1 = (rand()%100)+1;
    scanf("%d",&input1);
    if(random1 == input1)
    {
        printf("Bingo");
    }
    else
    {
        printf("Wrong 1 time");
        scanf("%d",&input2);
        if(random1 == input2){
            printf("Bingo");
        }
        else
        {
            printf("Wrong 2 time");
            scanf("%d",&input3);
            if (random1 == input3){

                printf("Bingo");
            }
            else
            {
                printf("Wrong 3 time");
                printf("Answer : %d",random1);
            }
        }
    }

    return 0;
}
