#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n1,n2,a;

    srand(time(NULL));

    n1 = (rand()%13+1);
    n2 = (rand()%13+1);
    a = (rand()%13+1);

    printf("n1= %d\n",n1);
    printf("n2= %d\n",n2);
    printf("a= %d\n",a);

    if(n1==n2)
    {
        printf("���Ӥ@��");
    }
    else if(n2-n1==1 ||n2-n1==-1)
    {
        printf("�߿�");
    }
    else
    {
        if(a==n1 || a==n2)
        printf("�����A������");
        else
        {
            if(n1>n2)
            {
                if(a<n1&&a>n2)
                    printf("Ĺ�F");
                else
                    printf("�߿�");
            }
            else
            {
                if(a>n1&&a<n2)
                    printf("Ĺ�F");
                else
                    printf("�߿�");

            }
        }

    }

    return 0;
}
