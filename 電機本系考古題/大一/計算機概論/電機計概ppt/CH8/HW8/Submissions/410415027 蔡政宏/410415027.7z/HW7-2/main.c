#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *inp;

    inp=fopen("welcome.txt","r");

    int sum=0;
    char a;
    int status;
    status=fscanf(inp,"%c",&a);
//    printf("%c\n", a);
    while(status!=EOF)
    {
        sum++;
        printf("%c\n", a);
        status=fscanf(inp,"%c",&a);
    }
    printf("sum=%d",sum);

    return 0;
}
