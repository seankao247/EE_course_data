#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *input;

    input = fopen("password.txt","r");

    int a;
    int i=0;
    int status;
    int ans[7]={0};

    status = fscanf(input,"%d",&a);

    while(status!=EOF)
    {
        printf("original:%d\n",a);

        int newans=0;
        int n=1;
        for(i=0;i<7;i++)
        {
            ans[i]=a%10;
            a/=10;
            ans[i]+=3;

            if(ans[i]>9)
            {
                ans[i]=ans[i]%10;
            }
            newans += ans[i]*n;
            n=n*10;

        }
        printf("after:%d\n",newans);

        status = fscanf(input,"%d",&a);
    }

    fclose(input);

    return 0;
}
