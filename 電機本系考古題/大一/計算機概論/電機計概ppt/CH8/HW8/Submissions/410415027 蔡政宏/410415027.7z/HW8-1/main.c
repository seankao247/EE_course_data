#include <stdio.h>
#include <stdlib.h>

void twosum(int);

int main()
{
    int sum=12;
    printf("Given target= %d\n",sum);
    twosum(sum);
    return 0;
}

void twosum(int target)
{
    FILE * input;

    input = fopen("list.txt", "r");

    int i=0,j=0, status;
    int ans;
    int a[6]={0};

    status=fscanf(input,"%d",&ans);

    while(status!=EOF)
    {
        a[i] = ans;
        i++;
        status=fscanf(input,"%d",&ans);
    }


    printf("output is:");
    for(i=0;i<6;i++)
        printf("%d  ",a[i]);
    printf("\n");
    for(i=0;i<6;i++)
    {
        for(j=i+1;j<6;j++)
        {
            if(a[i]+a[j]==target)
            {
                printf("array[%d],array[%d]\n",i,j);
            }
        }
    }


}
