#include <stdio.h>
#include <stdlib.h>

int a(int );
int b(int );
void c(int, int, int, int);

int main()
{
    int a1, a2, a3, a4;
    a2 = b(1);
    a1 = a(1);

    a4 = b(2);
    a3 = a(2);

    c(a1, a2, a3, a4);
    return 0;
}

int a(int i)
{
    int m1=0;
    srand(time(NULL)*i);
    m1=(rand()%13)+1;
    switch(m1)
    {
        case 1:
            printf("A\n");
            break;
        case 11:
            printf("J\n");
            break;
        case 12:
            printf("Q\n");
            break;
        case 13:
            printf("K\n");
            break;
        default:
            printf("%d\n",m1);
            break;
    }
    return m1;
}

int b(int i)
{
    int c1=0;
    srand(time(NULL)*i);
    c1=(rand()%4)+1;
    switch(c1)
    {
        case 4:
            printf("spade-");
            break;
        case 3:
            printf("heart-");
            break;
        case 2:
            printf("diamond-");
            break;
        case 1:
            printf("club-");
            break;
    }
    return c1;
}

void c(int a1, int a2, int a3, int a4)
{

    if(a1>a3)
    {
        printf("\nA win");
    }
    else if(a1<a3)
    {
        printf("\nB win");
    }
    else
    {
        printf("\neven");
    }
}
