#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x=0,i;
    int array[31];

    for(i=0; i<31; i++)
    {
        if(i==0)
            {array[i]=0;
            }
        else if(i==1 || i==2)
            {array[i]=1;
            }
        else
            {array[i]=array[i-1]+array[i-2];}
            x=x+array[i];
            printf("array[%d]=%d\n",i,array[i]);
    }
    printf("x=%d",x);

    return 0;
}
