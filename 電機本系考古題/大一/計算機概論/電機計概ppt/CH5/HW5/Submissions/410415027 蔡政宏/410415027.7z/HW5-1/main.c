#include <stdio.h>
#include <stdlib.h>

int main()
{
    int A=0,B=0,C=0,D=0,E=0,F=0,face;

    int x=0;
    srand(time(NULL));

    for(x=0; x<6000; x++)
    {
        face = (rand()%6)+1;
        if(face == 1)
            A++;
        else if(face == 2)
            B++;
        else if(face == 3)
            C++;
        else if(face == 4)
            D++;
        else if(face == 5)
            E++;
        else if(face == 6)
            F++;
    }
    printf("one:%d\n two:%d\n three:%d\n four:%d\n five:%d\n six:%d\n",A,B,C,D,E,F);
    int y=A+B+C+D+E+F;
    printf("sum:%d",y);
    system("pause");
    return 0;
}
