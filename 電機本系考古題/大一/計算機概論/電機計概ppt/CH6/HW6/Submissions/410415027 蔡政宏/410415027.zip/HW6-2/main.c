#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a=0,b=0,layer=0,i=0,j=0;
    printf("enter number:");
    scanf("%d",&a);
    printf("enter number:");
    scanf("%d",&b);

    if(a==b||(a+b)%2==1)
    {
        printf("please enter again\n");
    }
    else if(a>b)
    {
        layer=(a-b)/2+1;
        printf("layer : %d\n",layer);
        for(i=0;i<layer;i++)
        {
            for(j=0;j<a-i;j++)
            {
                if(j>=i)
                    printf("*");
                else
                    printf(" ");
            }
            printf("\n");

        }
        return 0;

    }
    else
    {
        layer=(b-a)/2+1;
        printf("layer : %d\n",layer);
        for(i=0;i<layer;i++)
        {
            for(j=0;j<layer+a+i-1;j++)
            {
                if(j>=layer-i-1)
                    printf("*");
                else
                    printf(" ");
            }
            printf("\n");
        }
        return 0;

    }

    return 0;
}
