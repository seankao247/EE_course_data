#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i=0,x=0,j=0,t=0;
    int array[10];

    while(i<10)
    {
        printf("Please enter number:");
        scanf("%d",&array[i]);
        printf("you enter[%d] in array[%d]\n",array[i],i);
        x=x+array[i];
        if(array[i]==0)
        {
            for(j=0;j<i+1;j++)
            {
                printf("%d ",array[j]);
            }

                break;
        }
        else if(i==9)
        {
           for(t=0;t<10;t++)
            {
                printf("%d ",array[t]);
            }
                break;
        }
        else
        {
            i++;
        }

    }


    printf("\nsum=%d",x);

    return 0;
}
